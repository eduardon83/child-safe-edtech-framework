CSEF label package
==================

Prepared with the Child-Safe EdTech Framework (CSEF). It describes one product for a label or catalogue.

metadata/sg-mdf.json, sg-mdf.xml  Serious Games Metadata Format (DIN SPEC 91380), CSEF serialisation
metadata/lrmi.jsonld              schema.org LearningResource description
csef/findings.json                CSEF scan results (child safety, privacy, commercial practices, design)
precheck/                         serious-game quality pre-check (criteria of Caserman et al. 2020)
evidence/index.json               evidence the team cites, with links or file paths
MANIFEST.json                     list of files with SHA-256 hashes

The pre-check is not a label. No labelling body issued or endorsed this package. It holds no learner data.

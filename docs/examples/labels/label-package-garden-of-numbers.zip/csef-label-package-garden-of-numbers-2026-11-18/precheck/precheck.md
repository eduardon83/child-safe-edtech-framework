# Serious-game quality pre-check: Garden of Numbers (good example)

*This pre-check maps CSEF results and the team's own statements to the serious-game quality criteria of Caserman et al. (2020). It is not a quality label, and no labelling body issued or endorsed it.*

Generated 2026-11-18T08:13:11+00:00 by csef-precheck 0.13.0. Criteria: Caserman P. et al. (2020). Quality criteria for serious games: serious part, game part, and balance. JMIR Serious Games 8(3):e19037. doi:10.2196/19037

**Characterizing goal.** Pupils aged 6 to 9 understand and compare simple fractions.

**Summary.** 4 ready, 5 partial, 13 missing, 0 with a CSEF issue (of 22). CSEF scan at level 2: 0 blocking, 0 to review. Compass not run.

## Serious part

| Criterion | Status | CSEF coverage | What is missing |
|---|---|---|---|
| SG-01 Focus on the characterizing goal | Partial | CSEF checks part of it | Compass not run (EDU-01) |
| SG-02 Clear goals | Missing | CSEF checks part of it | statement with evidence missing (serious_game.claims.SG-02); Compass not run (EDU-01) |
| SG-03 The serious part cannot be skipped | Ready | Team statement needed | nothing |
| SG-04 Correct, neutral content that fits the players | Missing | Team statement needed | statement with evidence missing (serious_game.claims.SG-04); Compass not run (TRN-07) |
| SG-05 Feedback on progress | Partial | CSEF checks it | CORE-ACC-05 needs review in the CSEF report |
| SG-06 Rewards used deliberately | Ready | CSEF checks it | nothing |
| SG-07 Proof of effectiveness and lasting effects | Partial | CSEF checks it | Compass not run (EDU-03) |
| SG-08 Awards, ratings and expert recommendations | Missing | Team statement needed | statement with evidence missing (serious_game.claims.SG-08) |

## Game part

| Criterion | Status | CSEF coverage | What is missing |
|---|---|---|---|
| SG-09 Engaging for different player types | Ready | Team statement needed | nothing |
| SG-10 Flow and adaptive difficulty | Missing | CSEF checks part of it | statement with evidence missing (serious_game.claims.SG-10); Compass not run (EDU-04, TRN-03) |
| SG-11 Emotional connection | Missing | CSEF sets limits for children | statement with evidence missing (serious_game.claims.SG-11); CORE-COM-03 needs review in the CSEF report; CORE-AI-02 needs review in the CSEF report |
| SG-12 Sense of control | Missing | CSEF checks part of it | statement with evidence missing (serious_game.claims.SG-12) |
| SG-13 Social play and game modes | Missing | CSEF sets limits for children | statement with evidence missing (serious_game.claims.SG-13) |
| SG-14 Immersive experience | Missing | CSEF checks part of it | statement with evidence missing (serious_game.claims.SG-14); CORE-ACC-04 needs review in the CSEF report; CORE-ACC-02 needs review in the CSEF report |
| SG-15 Graphics that fit, and a clear interface | Partial | CSEF checks it | CORE-ACC-01 needs review in the CSEF report; CORE-ACC-05 needs review in the CSEF report |
| SG-16 Appropriate sound | Missing | CSEF checks part of it | statement with evidence missing (serious_game.claims.SG-16); CORE-ACC-04 needs review in the CSEF report |

## Balance between serious and game part

| Criterion | Status | CSEF coverage | What is missing |
|---|---|---|---|
| SG-17 Learning built into the gameplay | Missing | CSEF checks part of it | statement with evidence missing (serious_game.claims.SG-17); Compass not run (EDU-01) |
| SG-18 Scientific foundation and a mixed team | Ready | Team statement needed | nothing |
| SG-19 Interaction technology that fits the players | Partial | CSEF checks it | CORE-ACC-01 needs review in the CSEF report |
| SG-20 Intuitive controls and tutorials | Missing | CSEF checks part of it | statement with evidence missing (serious_game.claims.SG-20); CORE-ACC-01 needs review in the CSEF report |
| SG-21 No shortcuts around the learning | Missing | CSEF checks part of it | statement with evidence missing (serious_game.claims.SG-21) |
| SG-22 No adverse effects | Missing | CSEF checks part of it | statement with evidence missing (serious_game.claims.SG-22); CORE-ACC-02 needs review in the CSEF report |

## Details

### SG-01 Focus on the characterizing goal · Partial

The learning or training goal stays in focus during play, and game elements do not get in its way.

CSEF rules: A-MOT-03 (ok), CORE-DES-02 (ok)
Compass: EDU-01 (level not run, needs 2)
Statement: Every garden plot is a fraction task; decorations never interrupt a task.
- Evidence: docs/design-document.md (found)

### SG-02 Clear goals · Missing

Players always know what to do to move towards the goal; complex games show it first or offer a tutorial.

Compass: EDU-01 (level not run, needs 2)
Evidence that fits: design document, playtest

### SG-03 The serious part cannot be skipped · Ready

Learning tasks are needed to play, cannot be avoided, and do not feel like a hurdle before the fun part.

CSEF rules: A-MOT-01 (ok)
Statement: Paths only open when a fraction task is solved; there is no way around them.
- Evidence: docs/design-document.md (found)

### SG-04 Correct, neutral content that fits the players · Missing

No subject errors and correct terminology; neutral on political and social issues; suitable for the culture and traditions of the target group.

CSEF rules: CORE-DES-04 (ok)
Compass: TRN-07 (level not run, needs 2)
Evidence that fits: subject expert review, curriculum mapping

### SG-05 Feedback on progress · Partial

Players see their performance and progress clearly, ideally through more than one sense (visual, audio, haptic).

CSEF rules: A-MOT-02 (ok), A-PLY-02 (ok), CORE-ACC-05 (review)
Evidence that fits: screens

### SG-06 Rewards used deliberately · Ready

Positive reinforcement and in-game awards, without rewards that control players and undermine intrinsic motivation.

CSEF rules: A-MOT-01 (ok), A-MOT-03 (ok), A-MOT-05 (ok), C-ENG-04 (ok), CORE-DES-06 (ok)
Evidence that fits: reward inventory

### SG-07 Proof of effectiveness and lasting effects · Partial

A study shows that players reach the goal and that the effect lasts; randomised controlled trials are the strongest evidence.

Compass: EDU-03 (level not run, needs 3)
Evidence that fits: study

### SG-08 Awards, ratings and expert recommendations · Missing

Game awards, professional and user ratings, expert recommendations, reviews and numbers of players.

Evidence that fits: award, rating, recommendation, usage figures

### SG-09 Engaging for different player types · Ready

A positive, enjoyable play experience, with something for different kinds of players.

Statement: Playtested with two classes (41 pupils); most wanted to keep playing.
- Evidence: docs/playtest-summary.md (found)

### SG-10 Flow and adaptive difficulty · Missing

Challenge matches skill and grows as players improve ("easy to learn, hard to master"); play is varied; difficulty adapts to the player.

*For children, CSEF applies:* Adaptive difficulty that uses learner data must be explained to children (TRN-03); if AI places or evaluates learners, a teacher reviews it (CORE-AI-07).

CSEF rules: C-ENG-06 (ok), CORE-AI-07 (ok)
Compass: EDU-04 (level not run, needs 2), TRN-03 (level not run, needs 2)
Evidence that fits: design document, playtest

### SG-11 Emotional connection · Missing

The game evokes emotions and draws on instincts such as collecting or overcoming danger to keep players engaged.

*For children, CSEF applies:* Emotions yes, pressure no. No guilt, fear of missing out, loss framing, random rewards or AI characters that simulate a relationship.

CSEF rules: CORE-COM-03 (review), CORE-AI-02 (review), CORE-AI-06 (ok), C-ENG-04 (ok), A-PLY-01 (ok)
Evidence that fits: design document

### SG-12 Sense of control · Missing

Players control their actions and see how their choices change the game world or the story.

CSEF rules: A-MOT-04 (ok)
Evidence that fits: design document

### SG-13 Social play and game modes · Missing

Different modes, cooperative and competitive, for players who do better in groups.

*For children, CSEF applies:* Competition stays inside the class, with nicknames, a teacher switch and team goals. No public high scores of named children; under 10, preset messages only.

CSEF rules: C-ENG-02 (ok), CORE-CHT-12 (ok), CORE-CHT-02 (ok), AGE-B2-01 (ok), A-MOT-03 (ok)
Evidence that fits: design document

### SG-14 Immersive experience · Missing

Several senses are engaged (visual, audio, haptic) to create a sense of "being there".

*For children, CSEF applies:* Under 8, calm screens come first; motion and sound can always be turned down or paused.

CSEF rules: CORE-DES-01 (ok), CORE-DES-03 (ok), CORE-ACC-04 (review), CORE-ACC-02 (review)
Evidence that fits: design document

### SG-15 Graphics that fit, and a clear interface · Partial

Graphics suit the purpose, the field and the target group; the interface shows nothing that distracts from the task.

CSEF rules: CORE-DES-03 (ok), CORE-DES-05 (ok), CORE-ACC-01 (review), CORE-ACC-05 (review)
Evidence that fits: screens

### SG-16 Appropriate sound · Missing

Background music and sound effects suit the game.

CSEF rules: CORE-DES-01 (ok), CORE-ACC-04 (review)
Evidence that fits: design document

### SG-17 Learning built into the gameplay · Missing

Learning tasks are part of the game world and its story, not a gate in front of a reward.

CSEF rules: A-MOT-01 (ok)
Compass: EDU-01 (level not run, needs 2)
Evidence that fits: design document, learning and game mechanics map

### SG-18 Scientific foundation and a mixed team · Ready

Game designers and subject experts work together from the start, with the target group, using the state of the art in each field.

Statement: Designed by game designers with two primary teachers and a maths education researcher.
- Evidence: docs/design-document.md (found)

### SG-19 Interaction technology that fits the players · Partial

Devices and controls suit the physical and mental abilities of the target group and the purpose of the game.

CSEF rules: CORE-ACC-01 (review), CORE-ACC-03 (ok)
Evidence that fits: accessibility report

### SG-20 Intuitive controls and tutorials · Missing

Players understand how to play quickly; complex games teach both how to act and what to do.

CSEF rules: CORE-ACC-01 (review)
Evidence that fits: playtest

### SG-21 No shortcuts around the learning · Missing

Technical features do not let players reach the goal without doing the learning or training, for example by cheating the tracking.

CSEF rules: A-ASM-01 (ok)
Evidence that fits: design document, playtest

### SG-22 No adverse effects · Missing

Low risk of accidents, injuries or overload; breaks are suggested; few technical issues and easy maintenance.

CSEF rules: CORE-SAF-03 (ok), CORE-ACC-02 (review), CORE-DES-01 (ok), C-ENG-06 (ok), CORE-SEC-05 (ok)
Evidence that fits: risk notes, maintenance plan
